# Liquidity Sweep Control

Flutter Android dashboard project.

## GitHub Actions
Workflow:
`.github/workflows/build_apk.yml`

It builds a release APK with Flutter and uploads:
`LiquiditySweepControl-release`

## Important
The dashboard UI is separate from the MT5 EA communication layer. The APK build can work without MT5 connectivity; EA control requires a transport such as the Telegram command interface already present in the Liquidity Sweep EA.
