# Liquidity Sweep Control Dashboard

Flutter Android dashboard for the Liquidity Sweep EA v1.08 parameter set.

Included:
- Dashboard
- Start / Stop / Pause
- Swing Bars
- SL / TP
- Lot Mode
- Initial Lot
- Recovery Multiplier
- Max Lot
- Max Recovery Orders
- Daily Target / Daily Loss
- Show Arrows
- Mobile Push
- Telegram Poll Seconds
- Logs
- Alerts

Important:
This version is a UI/state prototype. It does not yet communicate with MT5.
The next integration step is App -> EA command transport.
