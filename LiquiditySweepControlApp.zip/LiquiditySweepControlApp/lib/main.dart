import 'package:flutter/material.dart';

void main() {
  runApp(const LiquiditySweepApp());
}

class LiquiditySweepApp extends StatelessWidget {
  const LiquiditySweepApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Liquidity Sweep Control',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0B0F14),
        cardColor: const Color(0xFF151B23),
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.greenAccent,
          brightness: Brightness.dark,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.transparent,
          elevation: 0,
        ),
      ),
      home: const MainNavigationScreen(),
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _selectedIndex = 0;

  bool isConnected = true;
  bool isBotRunning = true;
  bool tradingPaused = false;

  String selectedBroker = 'Exness';
  String selectedServer = 'Exness-Exness-MT5Real30';
  String selectedAccountType = 'Live';
  String loginId = '224825781';

  int swingBars = 15;
  double slPoints = 5000;
  double tpPoints = 5000;
  String lotMode = 'Step';
  double initialLot = 0.01;
  double recoveryMultiplier = 2.00;
  double maxLot = 0.05;
  int maxRecoveryOrders = 2;
  bool enableDailyTarget = false;
  double dailyTarget = 500;
  bool enableDailyLoss = false;
  double dailyLoss = 500;
  bool showArrows = true;
  bool enableMobilePush = true;
  int telegramPollSeconds = 2;

  int buyRecovery = 0;
  int sellRecovery = 0;
  double todayProfit = 0.0;
  String currentSymbol = 'BTCUSD';
  String currentTimeframe = 'M1';
  String lastSignal = 'NONE';

  List<Map<String, String>> logs = [
    {'time': '18:02:15', 'message': 'Liquidity Sweep initialized', 'type': 'success'},
    {'time': '18:00:00', 'message': 'Connected to MT5 Server', 'type': 'success'},
    {'time': '17:58:30', 'message': 'EA Magic: 20260915', 'type': 'info'},
  ];

  List<Map<String, String>> alerts = [
    {'title': 'Liquidity Sweep', 'desc': 'Waiting for sweep signal...', 'time': 'Now'},
    {'title': 'Connection Stable', 'desc': 'MT5 connection is active', 'time': '1 min ago'},
  ];

  void addLog(String message, String type) {
    setState(() {
      logs.insert(0, {
        'time': TimeOfDay.now().format(context),
        'message': message,
        'type': type,
      });
    });
  }

  void toggleBot(bool value) {
    setState(() {
      isBotRunning = value;
      if (value) tradingPaused = false;
      logs.insert(0, {
        'time': TimeOfDay.now().format(context),
        'message': value ? 'Liquidity Sweep BOT STARTED' : 'Liquidity Sweep BOT STOPPED',
        'type': value ? 'success' : 'warning',
      });
    });
  }

  void togglePause(bool value) {
    setState(() {
      tradingPaused = value;
      logs.insert(0, {
        'time': TimeOfDay.now().format(context),
        'message': value ? 'Trading PAUSED' : 'Trading RESUMED',
        'type': value ? 'warning' : 'success',
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomeScreen(
        isConnected: isConnected,
        isBotRunning: isBotRunning,
        tradingPaused: tradingPaused,
        selectedBroker: selectedBroker,
        selectedServer: selectedServer,
        selectedAccountType: selectedAccountType,
        loginId: loginId,
        currentSymbol: currentSymbol,
        currentTimeframe: currentTimeframe,
        todayProfit: todayProfit,
        lastSignal: lastSignal,
        buyRecovery: buyRecovery,
        sellRecovery: sellRecovery,
        onBotToggle: toggleBot,
        onPauseToggle: togglePause,
      ),
      SettingsScreen(
        swingBars: swingBars,
        slPoints: slPoints,
        tpPoints: tpPoints,
        lotMode: lotMode,
        initialLot: initialLot,
        recoveryMultiplier: recoveryMultiplier,
        maxLot: maxLot,
        maxRecoveryOrders: maxRecoveryOrders,
        enableDailyTarget: enableDailyTarget,
        dailyTarget: dailyTarget,
        enableDailyLoss: enableDailyLoss,
        dailyLoss: dailyLoss,
        showArrows: showArrows,
        enableMobilePush: enableMobilePush,
        telegramPollSeconds: telegramPollSeconds,
        onSave: ({
          required int swingBarsValue,
          required double slValue,
          required double tpValue,
          required String lotModeValue,
          required double initialLotValue,
          required double multiplierValue,
          required double maxLotValue,
          required int maxRecoveryValue,
          required bool dailyTargetEnabled,
          required double dailyTargetValue,
          required bool dailyLossEnabled,
          required double dailyLossValue,
          required bool arrowsValue,
          required bool pushValue,
          required int telegramSeconds,
        }) {
          setState(() {
            swingBars = swingBarsValue;
            slPoints = slValue;
            tpPoints = tpValue;
            lotMode = lotModeValue;
            initialLot = initialLotValue;
            recoveryMultiplier = multiplierValue;
            maxLot = maxLotValue;
            maxRecoveryOrders = maxRecoveryValue;
            enableDailyTarget = dailyTargetEnabled;
            dailyTarget = dailyTargetValue;
            enableDailyLoss = dailyLossEnabled;
            dailyLoss = dailyLossValue;
            showArrows = arrowsValue;
            enableMobilePush = pushValue;
            telegramPollSeconds = telegramSeconds;
          });
          addLog('Liquidity Sweep parameters updated', 'success');
        },
      ),
      LogsScreen(logs: logs),
      AlertsScreen(alerts: alerts),
    ];

    return Scaffold(
      body: pages[_selectedIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (index) => setState(() => _selectedIndex = index),
        backgroundColor: const Color(0xFF11161D),
        indicatorColor: Colors.greenAccent.withOpacity(0.18),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Dashboard'),
          NavigationDestination(icon: Icon(Icons.tune_outlined), selectedIcon: Icon(Icons.tune), label: 'Settings'),
          NavigationDestination(icon: Icon(Icons.article_outlined), selectedIcon: Icon(Icons.article), label: 'Logs'),
          NavigationDestination(icon: Icon(Icons.notifications_none), selectedIcon: Icon(Icons.notifications), label: 'Alerts'),
        ],
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  final bool isConnected, isBotRunning, tradingPaused;
  final String selectedBroker, selectedServer, selectedAccountType, loginId;
  final String currentSymbol, currentTimeframe, lastSignal;
  final double todayProfit;
  final int buyRecovery, sellRecovery;
  final Function(bool) onBotToggle, onPauseToggle;

  const HomeScreen({
    super.key,
    required this.isConnected,
    required this.isBotRunning,
    required this.tradingPaused,
    required this.selectedBroker,
    required this.selectedServer,
    required this.selectedAccountType,
    required this.loginId,
    required this.currentSymbol,
    required this.currentTimeframe,
    required this.todayProfit,
    required this.lastSignal,
    required this.buyRecovery,
    required this.sellRecovery,
    required this.onBotToggle,
    required this.onPauseToggle,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.waterfall_chart, color: Colors.greenAccent),
          SizedBox(width: 10),
          Text('Liquidity Sweep', style: TextStyle(fontWeight: FontWeight.bold)),
        ]),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: _ConnectionBadge(connected: isConnected),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(14, 4, 14, 20),
        child: Column(children: [
          _buildBotStatusCard(),
          const SizedBox(height: 12),
          _buildMarketCard(),
          const SizedBox(height: 12),
          _buildAccountCard(),
          const SizedBox(height: 12),
          _buildProfitCard(),
          const SizedBox(height: 12),
          _buildRecoveryCard(),
          const SizedBox(height: 12),
          _buildSignalCard(),
          const SizedBox(height: 12),
          _buildControlCard(),
        ]),
      ),
    );
  }

  Widget _buildBotStatusCard() {
    final active = isBotRunning && !tradingPaused;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [
          const Color(0xFF151B23),
          active ? const Color(0xFF10251C) : const Color(0xFF24171A),
        ]),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: active ? Colors.greenAccent.withOpacity(0.45) : Colors.redAccent.withOpacity(0.4)),
      ),
      child: Row(children: [
        Container(
          width: 54, height: 54,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: active ? Colors.greenAccent.withOpacity(0.12) : Colors.redAccent.withOpacity(0.12),
          ),
          child: Icon(active ? Icons.bolt : Icons.pause_circle, color: active ? Colors.greenAccent : Colors.redAccent, size: 30),
        ),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('LIQUIDITY SWEEP EA', style: TextStyle(color: Colors.grey, fontSize: 11, letterSpacing: 1)),
          const SizedBox(height: 4),
          Text(
            !isBotRunning ? 'STOPPED' : tradingPaused ? 'PAUSED' : 'RUNNING',
            style: TextStyle(
              color: !isBotRunning ? Colors.redAccent : tradingPaused ? Colors.orangeAccent : Colors.greenAccent,
              fontWeight: FontWeight.bold, fontSize: 21,
            ),
          ),
          const SizedBox(height: 2),
          const Text('Magic: 20260915', style: TextStyle(color: Colors.grey, fontSize: 11)),
        ])),
      ]),
    );
  }

  Widget _buildMarketCard() => _SectionCard(
    title: 'MARKET', icon: Icons.candlestick_chart,
    child: Row(children: [
      Expanded(child: _MetricBox(label: 'SYMBOL', value: currentSymbol, icon: Icons.currency_bitcoin)),
      const SizedBox(width: 8),
      Expanded(child: _MetricBox(label: 'TIMEFRAME', value: currentTimeframe, icon: Icons.timer)),
      const SizedBox(width: 8),
      Expanded(child: _MetricBox(label: 'SWING', value: '15', icon: Icons.show_chart)),
    ]),
  );

  Widget _buildAccountCard() => _SectionCard(
    title: 'MT5 ACCOUNT', icon: Icons.account_balance_wallet,
    child: Column(children: [
      _InfoRow(label: 'Broker', value: selectedBroker),
      _InfoRow(label: 'Server', value: selectedServer),
      _InfoRow(label: 'Login', value: loginId),
      _InfoRow(label: 'Account', value: selectedAccountType),
      _InfoRow(label: 'Connection', value: isConnected ? 'CONNECTED' : 'OFFLINE',
        valueColor: isConnected ? Colors.greenAccent : Colors.redAccent),
    ]),
  );

  Widget _buildProfitCard() {
    final positive = todayProfit >= 0;
    return _SectionCard(
      title: 'TODAY', icon: Icons.analytics,
      child: Row(children: [
        Expanded(child: _MetricBox(
          label: 'CLOSED P/L',
          value: '${positive ? '+' : ''}${todayProfit.toStringAsFixed(2)}',
          icon: positive ? Icons.trending_up : Icons.trending_down,
          valueColor: positive ? Colors.greenAccent : Colors.redAccent,
        )),
        const SizedBox(width: 10),
        Expanded(child: _MetricBox(label: 'TARGET', value: 'OFF', icon: Icons.flag, valueColor: Colors.orangeAccent)),
      ]),
    );
  }

  Widget _buildRecoveryCard() => _SectionCard(
    title: 'RECOVERY', icon: Icons.replay,
    child: Row(children: [
      Expanded(child: _MetricBox(label: 'BUY', value: '$buyRecovery / 2', icon: Icons.arrow_upward, valueColor: Colors.greenAccent)),
      const SizedBox(width: 10),
      Expanded(child: _MetricBox(label: 'SELL', value: '$sellRecovery / 2', icon: Icons.arrow_downward, valueColor: Colors.redAccent)),
    ]),
  );

  Widget _buildSignalCard() => _SectionCard(
    title: 'LAST SIGNAL', icon: Icons.radar,
    child: Row(children: [
      Container(
        width: 48, height: 48,
        decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.blueAccent.withOpacity(0.12)),
        child: const Icon(Icons.radar, color: Colors.blueAccent),
      ),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(lastSignal, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 3),
        const Text('Waiting for liquidity sweep...', style: TextStyle(color: Colors.grey, fontSize: 12)),
      ])),
    ]),
  );

  Widget _buildControlCard() => _SectionCard(
    title: 'BOT CONTROL', icon: Icons.settings_remote,
    child: Column(children: [
      SwitchListTile(
        contentPadding: EdgeInsets.zero,
        title: const Text('Trading Pause', style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(
          tradingPaused ? 'EA จะไม่เปิดออเดอร์ใหม่' : 'EA สามารถทำงานตามระบบได้',
          style: const TextStyle(color: Colors.grey, fontSize: 11),
        ),
        value: tradingPaused,
        activeColor: Colors.orangeAccent,
        onChanged: isBotRunning ? onPauseToggle : null,
      ),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: ElevatedButton.icon(
          onPressed: () => onBotToggle(true),
          icon: const Icon(Icons.play_arrow),
          label: const Text('START', style: TextStyle(fontWeight: FontWeight.bold)),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.greenAccent, foregroundColor: Colors.black,
            padding: const EdgeInsets.symmetric(vertical: 15),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
        )),
        const SizedBox(width: 10),
        Expanded(child: ElevatedButton.icon(
          onPressed: () => onBotToggle(false),
          icon: const Icon(Icons.stop),
          label: const Text('STOP', style: TextStyle(fontWeight: FontWeight.bold)),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.redAccent, foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 15),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
        )),
      ]),
    ]),
  );
}

class SettingsScreen extends StatefulWidget {
  final int swingBars;
  final double slPoints, tpPoints, initialLot, recoveryMultiplier, maxLot;
  final String lotMode;
  final int maxRecoveryOrders, telegramPollSeconds;
  final bool enableDailyTarget, enableDailyLoss, showArrows, enableMobilePush;
  final double dailyTarget, dailyLoss;
  final Function({
    required int swingBarsValue, required double slValue, required double tpValue,
    required String lotModeValue, required double initialLotValue, required double multiplierValue,
    required double maxLotValue, required int maxRecoveryValue, required bool dailyTargetEnabled,
    required double dailyTargetValue, required bool dailyLossEnabled, required double dailyLossValue,
    required bool arrowsValue, required bool pushValue, required int telegramSeconds,
  }) onSave;

  const SettingsScreen({
    super.key, required this.swingBars, required this.slPoints, required this.tpPoints,
    required this.lotMode, required this.initialLot, required this.recoveryMultiplier, required this.maxLot,
    required this.maxRecoveryOrders, required this.enableDailyTarget, required this.dailyTarget,
    required this.enableDailyLoss, required this.dailyLoss, required this.showArrows,
    required this.enableMobilePush, required this.telegramPollSeconds, required this.onSave,
  });

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late int swingBars, maxRecoveryOrders, telegramPollSeconds;
  late double slPoints, tpPoints, initialLot, recoveryMultiplier, maxLot, dailyTarget, dailyLoss;
  late String lotMode;
  late bool enableDailyTarget, enableDailyLoss, showArrows, enableMobilePush;

  @override
  void initState() {
    super.initState();
    swingBars = widget.swingBars; slPoints = widget.slPoints; tpPoints = widget.tpPoints;
    lotMode = widget.lotMode; initialLot = widget.initialLot; recoveryMultiplier = widget.recoveryMultiplier;
    maxLot = widget.maxLot; maxRecoveryOrders = widget.maxRecoveryOrders;
    enableDailyTarget = widget.enableDailyTarget; dailyTarget = widget.dailyTarget;
    enableDailyLoss = widget.enableDailyLoss; dailyLoss = widget.dailyLoss;
    showArrows = widget.showArrows; enableMobilePush = widget.enableMobilePush;
    telegramPollSeconds = widget.telegramPollSeconds;
  }

  void saveSettings() {
    widget.onSave(
      swingBarsValue: swingBars, slValue: slPoints, tpValue: tpPoints, lotModeValue: lotMode,
      initialLotValue: initialLot, multiplierValue: recoveryMultiplier, maxLotValue: maxLot,
      maxRecoveryValue: maxRecoveryOrders, dailyTargetEnabled: enableDailyTarget,
      dailyTargetValue: dailyTarget, dailyLossEnabled: enableDailyLoss, dailyLossValue: dailyLoss,
      arrowsValue: showArrows, pushValue: enableMobilePush, telegramSeconds: telegramPollSeconds,
    );
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('บันทึก Liquidity Sweep Settings แล้ว')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Liquidity Sweep Settings', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [IconButton(onPressed: saveSettings, icon: const Icon(Icons.save, color: Colors.greenAccent))],
      ),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          _SettingsHeader(title: 'SIGNAL', subtitle: 'Liquidity Sweep detection', icon: Icons.radar),
          _NumberTile(title: 'Swing Bars', subtitle: 'แท่งย้อนหลังสำหรับหา Swing High / Swing Low', value: '$swingBars',
            onEdit: () async { final v = await _numberDialog(context, 'Swing Bars', '$swingBars'); if (v != null) setState(() => swingBars = v.clamp(2, 200)); }),
          const SizedBox(height: 8),

          _SettingsHeader(title: 'RISK / SL / TP', subtitle: 'Stop Loss และ Take Profit', icon: Icons.shield),
          _NumberTile(title: 'Stop Loss', subtitle: 'SL Points', value: slPoints.toStringAsFixed(0),
            onEdit: () async { final v = await _doubleDialog(context, 'Stop Loss Points', slPoints.toStringAsFixed(0)); if (v != null) setState(() => slPoints = v); }),
          _NumberTile(title: 'Take Profit', subtitle: 'TP Points', value: tpPoints.toStringAsFixed(0),
            onEdit: () async { final v = await _doubleDialog(context, 'Take Profit Points', tpPoints.toStringAsFixed(0)); if (v != null) setState(() => tpPoints = v); }),

          _SettingsHeader(title: 'LOT / RECOVERY', subtitle: 'ระบบเพิ่ม Lot หลังโดน Stop Loss', icon: Icons.replay_circle_filled),
          ListTile(
            title: const Text('Lot Mode'),
            subtitle: const Text('รูปแบบการคำนวณ Lot', style: TextStyle(color: Colors.grey)),
            trailing: DropdownButton<String>(
              value: lotMode,
              items: const [
                DropdownMenuItem(value: 'Step', child: Text('Step')),
                DropdownMenuItem(value: 'Multiplier', child: Text('Multiplier')),
              ],
              onChanged: (v) { if (v != null) setState(() => lotMode = v); },
            ),
          ),
          _NumberTile(title: 'Initial Lot', subtitle: 'Lot เริ่มต้น', value: initialLot.toStringAsFixed(2),
            onEdit: () async { final v = await _doubleDialog(context, 'Initial Lot', initialLot.toStringAsFixed(2)); if (v != null) setState(() => initialLot = v); }),
          _NumberTile(title: 'Recovery Multiplier', subtitle: 'ตัวคูณ Lot Recovery', value: recoveryMultiplier.toStringAsFixed(2),
            onEdit: () async { final v = await _doubleDialog(context, 'Recovery Multiplier', recoveryMultiplier.toStringAsFixed(2)); if (v != null) setState(() => recoveryMultiplier = v); }),
          _NumberTile(title: 'Max Lot', subtitle: 'Lot สูงสุดที่ EA อนุญาต', value: maxLot.toStringAsFixed(2),
            onEdit: () async { final v = await _doubleDialog(context, 'Max Lot', maxLot.toStringAsFixed(2)); if (v != null) setState(() => maxLot = v); }),
          _NumberTile(title: 'Max Recovery Orders', subtitle: 'จำนวน Recovery สูงสุดต่อฝั่ง', value: '$maxRecoveryOrders',
            onEdit: () async { final v = await _numberDialog(context, 'Max Recovery Orders', '$maxRecoveryOrders'); if (v != null) setState(() => maxRecoveryOrders = v.clamp(0, 20)); }),

          const SizedBox(height: 8),
          _SettingsHeader(title: 'DAILY CONTROL', subtitle: 'หยุดการเทรดเมื่อถึงกำไร/ขาดทุนประจำวัน', icon: Icons.calendar_today),
          SwitchListTile(
            title: const Text('Enable Daily Target'),
            subtitle: Text(enableDailyTarget ? 'หยุดเมื่อกำไรถึง ${dailyTarget.toStringAsFixed(2)}' : 'ปิดใช้งาน',
              style: const TextStyle(color: Colors.grey, fontSize: 12)),
            value: enableDailyTarget, activeColor: Colors.greenAccent,
            onChanged: (v) => setState(() => enableDailyTarget = v),
          ),
          if (enableDailyTarget) _NumberTile(title: 'Daily Target', subtitle: 'เป้าหมายกำไรต่อวัน',
            value: dailyTarget.toStringAsFixed(2),
            onEdit: () async { final v = await _doubleDialog(context, 'Daily Target', dailyTarget.toStringAsFixed(2)); if (v != null) setState(() => dailyTarget = v); }),
          SwitchListTile(
            title: const Text('Enable Daily Loss'),
            subtitle: Text(enableDailyLoss ? 'หยุดเมื่อขาดทุนถึง ${dailyLoss.toStringAsFixed(2)}' : 'ปิดใช้งาน',
              style: const TextStyle(color: Colors.grey, fontSize: 12)),
            value: enableDailyLoss, activeColor: Colors.redAccent,
            onChanged: (v) => setState(() => enableDailyLoss = v),
          ),
          if (enableDailyLoss) _NumberTile(title: 'Daily Loss', subtitle: 'ขาดทุนสูงสุดต่อวัน',
            value: dailyLoss.toStringAsFixed(2),
            onEdit: () async { final v = await _doubleDialog(context, 'Daily Loss', dailyLoss.toStringAsFixed(2)); if (v != null) setState(() => dailyLoss = v); }),

          const SizedBox(height: 8),
          _SettingsHeader(title: 'NOTIFICATIONS', subtitle: 'การแจ้งเตือนและกราฟ', icon: Icons.notifications_active),
          SwitchListTile(
            title: const Text('Show Arrows'),
            subtitle: const Text('แสดงลูกศร Buy / Sell บนกราฟ MT5', style: TextStyle(color: Colors.grey, fontSize: 12)),
            value: showArrows, activeColor: Colors.greenAccent,
            onChanged: (v) => setState(() => showArrows = v),
          ),
          SwitchListTile(
            title: const Text('Mobile Push'),
            subtitle: const Text('ส่งสัญญาณเข้าโทรศัพท์', style: TextStyle(color: Colors.grey, fontSize: 12)),
            value: enableMobilePush, activeColor: Colors.greenAccent,
            onChanged: (v) => setState(() => enableMobilePush = v),
          ),
          _NumberTile(title: 'Telegram Poll Seconds', subtitle: 'ความถี่ในการตรวจคำสั่ง Telegram',
            value: '$telegramPollSeconds',
            onEdit: () async { final v = await _numberDialog(context, 'Telegram Poll Seconds', '$telegramPollSeconds'); if (v != null) setState(() => telegramPollSeconds = v.clamp(1, 60)); }),
          const SizedBox(height: 20),
          ElevatedButton.icon(
            onPressed: saveSettings, icon: const Icon(Icons.save),
            label: const Text('SAVE LIQUIDITY SWEEP SETTINGS', style: TextStyle(fontWeight: FontWeight.bold)),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.greenAccent, foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(vertical: 17),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),
          const SizedBox(height: 30),
        ],
      ),
    );
  }

  Future<int?> _numberDialog(BuildContext context, String title, String initial) async {
    final c = TextEditingController(text: initial);
    return showDialog<int>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: TextField(controller: c, keyboardType: TextInputType.number, autofocus: true,
          decoration: const InputDecoration(border: OutlineInputBorder())),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(onPressed: () => Navigator.pop(context, int.tryParse(c.text)), child: const Text('OK')),
        ],
      ),
    );
  }

  Future<double?> _doubleDialog(BuildContext context, String title, String initial) async {
    final c = TextEditingController(text: initial);
    return showDialog<double>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: TextField(controller: c, keyboardType: const TextInputType.numberWithOptions(decimal: true), autofocus: true,
          decoration: const InputDecoration(border: OutlineInputBorder())),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(onPressed: () => Navigator.pop(context, double.tryParse(c.text)), child: const Text('OK')),
        ],
      ),
    );
  }
}

class LogsScreen extends StatelessWidget {
  final List<Map<String, String>> logs;
  const LogsScreen({super.key, required this.logs});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('System Logs', style: TextStyle(fontWeight: FontWeight.bold))),
      body: logs.isEmpty ? const Center(child: Text('ไม่มีข้อมูล Log')) :
        ListView.builder(
          padding: const EdgeInsets.all(14),
          itemCount: logs.length,
          itemBuilder: (_, i) {
            final log = logs[i];
            final type = log['type'];
            final color = type == 'success' ? Colors.greenAccent : type == 'warning' ? Colors.orangeAccent : Colors.blueAccent;
            final icon = type == 'success' ? Icons.check_circle : type == 'warning' ? Icons.warning : Icons.info;
            return Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading: Icon(icon, color: color),
                title: Text(log['message'] ?? '', style: const TextStyle(fontSize: 14)),
                subtitle: Text(log['time'] ?? '', style: const TextStyle(color: Colors.grey, fontSize: 11)),
              ),
            );
          },
        ),
    );
  }
}

class AlertsScreen extends StatelessWidget {
  final List<Map<String, String>> alerts;
  const AlertsScreen({super.key, required this.alerts});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Notifications', style: TextStyle(fontWeight: FontWeight.bold))),
      body: alerts.isEmpty ? const Center(child: Text('ไม่มีการแจ้งเตือน')) :
        ListView.builder(
          padding: const EdgeInsets.all(14),
          itemCount: alerts.length,
          itemBuilder: (_, i) {
            final alert = alerts[i];
            return Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading: const Icon(Icons.notifications_active, color: Colors.orangeAccent),
                title: Text(alert['title'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(alert['desc'] ?? ''),
                trailing: Text(alert['time'] ?? '', style: const TextStyle(color: Colors.grey, fontSize: 10)),
              ),
            );
          },
        ),
    );
  }
}

class _ConnectionBadge extends StatelessWidget {
  final bool connected;
  const _ConnectionBadge({required this.connected});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: connected ? Colors.greenAccent.withOpacity(0.10) : Colors.redAccent.withOpacity(0.10),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: connected ? Colors.greenAccent.withOpacity(0.35) : Colors.redAccent.withOpacity(0.35)),
      ),
      child: Row(children: [
        Icon(Icons.circle, size: 8, color: connected ? Colors.greenAccent : Colors.redAccent),
        const SizedBox(width: 6),
        Text(connected ? 'CONNECTED' : 'OFFLINE',
          style: TextStyle(fontSize: 10, color: connected ? Colors.greenAccent : Colors.redAccent, fontWeight: FontWeight.bold)),
      ]),
    );
  }
}

class _SectionCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final Widget child;
  const _SectionCard({required this.title, required this.icon, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: const Color(0xFF151B23),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.05)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(icon, color: Colors.orangeAccent, size: 18),
          const SizedBox(width: 8),
          Text(title, style: const TextStyle(color: Colors.orangeAccent, fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: 0.7)),
        ]),
        const SizedBox(height: 13),
        child,
      ]),
    );
  }
}

class _MetricBox extends StatelessWidget {
  final String label, value;
  final IconData icon;
  final Color? valueColor;
  const _MetricBox({required this.label, required this.value, required this.icon, this.valueColor});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(11),
      decoration: BoxDecoration(color: const Color(0xFF0D1218), borderRadius: BorderRadius.circular(12)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, size: 17, color: Colors.grey),
        const SizedBox(height: 7),
        Text(label, style: const TextStyle(color: Colors.grey, fontSize: 9)),
        const SizedBox(height: 3),
        Text(value, maxLines: 1, overflow: TextOverflow.ellipsis,
          style: TextStyle(color: valueColor ?? Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
      ]),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label, value;
  final Color? valueColor;
  const _InfoRow({required this.label, required this.value, this.valueColor});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(width: 95, child: Text(label, style: const TextStyle(color: Colors.grey, fontSize: 12))),
        Expanded(child: Text(value, textAlign: TextAlign.right,
          style: TextStyle(color: valueColor ?? Colors.white, fontSize: 12, fontWeight: FontWeight.w500))),
      ]),
    );
  }
}

class _SettingsHeader extends StatelessWidget {
  final String title, subtitle;
  final IconData icon;
  const _SettingsHeader({required this.title, required this.subtitle, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 12, bottom: 8),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(color: Colors.orangeAccent.withOpacity(0.10), borderRadius: BorderRadius.circular(9)),
          child: Icon(icon, color: Colors.orangeAccent, size: 18),
        ),
        const SizedBox(width: 10),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(color: Colors.orangeAccent, fontWeight: FontWeight.bold, fontSize: 12)),
          Text(subtitle, style: const TextStyle(color: Colors.grey, fontSize: 10)),
        ]),
      ]),
    );
  }
}

class _NumberTile extends StatelessWidget {
  final String title, subtitle, value;
  final VoidCallback onEdit;
  const _NumberTile({required this.title, required this.subtitle, required this.value, required this.onEdit});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 4),
      child: ListTile(
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w500)),
        subtitle: Text(subtitle, style: const TextStyle(color: Colors.grey, fontSize: 11)),
        trailing: InkWell(
          onTap: onEdit,
          borderRadius: BorderRadius.circular(8),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
            decoration: BoxDecoration(
              color: Colors.greenAccent.withOpacity(0.08),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.greenAccent.withOpacity(0.25)),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Text(value, style: const TextStyle(color: Colors.greenAccent, fontWeight: FontWeight.bold)),
              const SizedBox(width: 5),
              const Icon(Icons.edit, size: 14, color: Colors.greenAccent),
            ]),
          ),
        ),
      ),
    );
  }
}
