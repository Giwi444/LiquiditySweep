LIQUIDITY SWEEP DASHBOARD v1.1

Phase 1: UI preview only.
- Dark mobile dashboard
- Running / Paused state
- Balance, Equity, P/L, Open Trades, Recovery
- BTCUSD sample position card
- Pause / Close All / Refresh demo buttons
- No MT5 or Telegram connection yet

Open this project in Android Studio and build the debug APK.
The visual preview is also available at preview/index.html.
